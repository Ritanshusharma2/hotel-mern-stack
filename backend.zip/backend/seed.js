const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Hotel = require('./models/Hotel');
const Room = require('./models/Room');
const Booking = require('./models/Booking');
const Review = require('./models/Review');

dotenv.config();

const users = [
  {
    name: 'Admin User',
    email: 'admin@hotel.com',
    password: 'admin12345',
    isAdmin: true,
    phone: '+1 555-0199',
  },
  {
    name: 'Jane Doe',
    email: 'user@hotel.com',
    password: 'user12345',
    isAdmin: false,
    phone: '+1 555-0123',
  },
];

const hotelsData = [
  {
    name: 'The Grand Plaza Resort',
    type: 'resort',
    city: 'Paris',
    address: '15 Avenue Montaigne, 75008 Paris',
    distance: '350m from center',
    images: [
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=1200&q=80',
    ],
    description: 'Immerse yourself in Parisian elegance. The Grand Plaza Resort offers timeless architecture, Michelin-starred dining, and an exquisite wellness spa overlooking the Eiffel Tower.',
    featured: true,
    rating: 4.8,
    numReviews: 120,
  },
  {
    name: 'Tokyo Ritz Luxury Suites',
    type: 'hotel',
    city: 'Tokyo',
    address: '9-7-1 Akasaka, Minato-ku, Tokyo 107-6245',
    distance: '1.2km from center',
    images: [
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
    ],
    description: 'Elevate your stay in Tokyo. Located high above the bustling streets, this modern oasis blends legendary luxury services with contemporary Japanese aesthetic touches.',
    featured: true,
    rating: 4.9,
    numReviews: 95,
  },
  {
    name: 'London Heritage Boutique Hotel',
    type: 'hotel',
    city: 'London',
    address: '12 Kensington High St, London W8 4PT',
    distance: '800m from center',
    images: [
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=80',
    ],
    description: 'Experience refined British luxury in the heart of Kensington. Featuring custom design details, a historic brick facade, and an exclusive lounge room for high tea.',
    featured: false,
    rating: 4.5,
    numReviews: 45,
  },
  {
    name: 'Aspen Alpine Wood Cabin',
    type: 'cabin',
    city: 'Aspen',
    address: '400 Wood Road, Snowmass Village, CO 81615',
    distance: '4.5km from center',
    images: [
      'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=80',
    ],
    description: 'Escape to a cozy winter wonderland. A gorgeous alpine log cabin equipped with private outdoor hot tubs, fire pit pits, and direct ski-in/ski-out accessibility.',
    featured: true,
    rating: 4.7,
    numReviews: 32,
  },
];

const roomsData = {
  'The Grand Plaza Resort': [
    {
      title: 'Classic Parisian Room',
      price: 250,
      maxPeople: 2,
      description: 'Elegant bedroom decorated with classic Louis XVI style furniture, plush queen size bedding, and high ceilings.',
      quantity: 5,
      amenities: ['Free Wi-Fi', 'Flat-screen TV', 'Mini Bar', 'Air Conditioning', 'Espresso Machine'],
      images: ['https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80'],
    },
    {
      title: 'Eiffel View Executive Suite',
      price: 520,
      maxPeople: 3,
      description: 'Spacious master suite featuring a separate living room area, private balcony with direct views of the Eiffel Tower, and marble bath.',
      quantity: 2,
      amenities: ['Balcony', 'Eiffel Tower View', 'Free Wi-Fi', '24/7 Room Service', 'Mini Bar', 'Bathrobe'],
      images: ['https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=800&q=80'],
    },
  ],
  'Tokyo Ritz Luxury Suites': [
    {
      title: 'Deluxe City View Room',
      price: 340,
      maxPeople: 2,
      description: 'Stunning floor-to-ceiling windows showing the Tokyo skyline. Features contemporary wood elements and a deep soaking tub.',
      quantity: 8,
      amenities: ['Skyline View', 'Smart TV', 'Free Wi-Fi', 'Air Conditioning', 'Deep Soaking Tub'],
      images: ['https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80'],
    },
    {
      title: 'Presidential Emperor Suite',
      price: 850,
      maxPeople: 4,
      description: 'The pinnacle of luxury. Fully integrated automation, formal dining area, private study, and personalized butler services.',
      quantity: 1,
      amenities: ['Butler Service', 'Dining Room', 'Free Wi-Fi', 'Jacuzzi', 'Champagne on Arrival'],
      images: ['https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80'],
    },
  ],
  'London Heritage Boutique Hotel': [
    {
      title: 'Queen Kensington Room',
      price: 190,
      maxPeople: 2,
      description: 'Comfortable boutique room with historic brick design accents, high-end pillowtop mattress, and rain shower.',
      quantity: 6,
      amenities: ['Free Wi-Fi', 'Rain Shower', 'Teatime Treats', 'Bluetooth Speakers'],
      images: ['https://images.unsplash.com/photo-1568495248636-6432b97bd949?auto=format&fit=crop&w=800&q=80'],
    },
  ],
  'Aspen Alpine Wood Cabin': [
    {
      title: 'Log Cabin Suite',
      price: 300,
      maxPeople: 4,
      description: 'Charming wood-paneled space with a stone fireplace, double king beds, and an outdoor patio with a hot tub.',
      quantity: 3,
      amenities: ['Fireplace', 'Outdoor Hot Tub', 'Kitchenette', 'Free Wi-Fi', 'Ski Lockers'],
      images: ['https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80'],
    },
  ],
};

const importData = async () => {
  try {
    console.log('Connecting to database for seeding...');
    await mongoose.connect(process.env.MONGO_URI);

    // Delete existing records
    await User.deleteMany();
    await Hotel.deleteMany();
    await Room.deleteMany();
    await Booking.deleteMany();
    await Review.deleteMany();

    console.log('Existing database entries cleared.');

    // Seed Users
    const createdUsers = await User.create(users);
    console.log(`Users Seeded: ${createdUsers.length}`);

    // Seed Hotels and Rooms
    for (let hData of hotelsData) {
      const hotel = new Hotel(hData);
      const savedHotel = await hotel.save();

      const roomsForHotel = roomsData[savedHotel.name] || [];
      const createdRoomsIds = [];

      for (let rData of roomsForHotel) {
        const room = new Room({
          ...rData,
          hotel: savedHotel._id,
        });
        const savedRoom = await room.save();
        createdRoomsIds.push(savedRoom._id);
      }

      // Update hotel with rooms array
      savedHotel.rooms = createdRoomsIds;
      await savedHotel.save();
    }

    console.log('Hotels and Rooms Seeded Successfully!');
    process.exit();
  } catch (error) {
    console.error(`Error with data import: ${error.message}`);
    process.exit(1);
  }
};

importData();
